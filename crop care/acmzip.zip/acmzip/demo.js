let DaysCounter=document.querySelector(".DaysCounter");
for(let i=1;i<=11;i++)
{
  let WeakDiv=document.createElement("div");
  WeakDiv.setAttribute("class","WeakDiv container row p-3");
  DaysCounter.append(document.createElement("p").innerText=`Weak ${i}`);
  DaysCounter.append(WeakDiv);
  for(let k=1;k<=7;k++)
  {
    let daysdiv=document.createElement("div");
    daysdiv.setAttribute("class","daysDiv p-3 ml-2");
    daysdiv.innerText=((i-1)*7)+k;
    WeakDiv.append(daysdiv);
  }
}
let daysDiv=document.querySelectorAll(".daysDiv");
daysDiv.forEach((target)=>{
  target.addEventListener("click",()=>{
    for(i=target.textContent;i>=1;i--)
      {
        daysDiv[i-1].style.backgroundColor = "blue";
      }
  })
})